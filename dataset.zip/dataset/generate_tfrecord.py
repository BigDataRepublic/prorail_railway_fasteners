"""Create tfrecord files.

For reference see: https://github.com/tensorflow/models/blob/master/research/object_detection/g3doc/using_your_own_dataset.mdgenerate_tfrecord.py

Usage
-----
Create train data:
python generate_tfrecord.py --label=<LABEL> --csv_input=<PATH_TO_ANNOTATIONS_FOLDER>/train_labels.csv \
--output_path=<PATH_TO_ANNOTATIONS_FOLDER>/train.record

Create test data:
python generate_tfrecord.py --label=<LABEL> --csv_input=<PATH_TO_ANNOTATIONS_FOLDER>/test_labels.csv \
--output_path=<PATH_TO_ANNOTATIONS_FOLDER>/test.record
"""

from __future__ import division
from __future__ import print_function
from __future__ import absolute_import

from absl import app, flags
import io
import os
import pandas as pd
from PIL import Image
import tensorflow as tf

from object_detection.utils import dataset_util, label_map_util
from collections import namedtuple

flags.DEFINE_string('csv_input', '', 'Path to the CSV input')
flags.DEFINE_string('output_path', '', 'Path to output TFRecord')
flags.DEFINE_string('path_to_labels', '', 'path to labelmap')
flags.DEFINE_string('img_path', '', 'Path to images')
FLAGS = flags.FLAGS


def split(df, group):
    """Return namedTuple containing labels of a filename instance.

    Parameters
    ----------
    df: pandas DataFrame
        pandas DataFrame of the csv containing all data samples
    group: column name in df to group by

    Returns
    -------
    List of namedTuples containing filename and a pandas DataFrame containing labels of all instances of the filename
    """
    data = namedtuple('data', ['filename', 'object'])
    gb = df.groupby(group)
    return [data(filename, gb.get_group(x)) for filename, x in zip(gb.groups.keys(), gb.groups)]


def create_tf_example(example, path):
    """Generate tfrecord entry from a namedTuple containing filename and features of all instances of the filename.

    Parameters
    ----------
    df: pandas DataFrame
        pandas DataFrame of the csv containing all data samples

    Returns
    -------
    tfrecord entry containing features (pixel values) of object (image) and labels
    """
    category_index = label_map_util.create_category_index_from_labelmap(FLAGS.path_to_labels, use_display_name=True)
    class_text_to_int = {category_index[i]['name']: i for i in category_index.keys()}

    with tf.io.gfile.GFile(os.path.join(path, '{}'.format(example.filename)), 'rb') as fid:
        encoded_jpg = fid.read()
    encoded_jpg_io = io.BytesIO(encoded_jpg)
    image = Image.open(encoded_jpg_io)
    width, height = image.size

    filename = example.filename.encode('utf8')

    image_format = b'jpg'
    # check if the image format is matching with your images.
    xmins = []
    xmaxs = []
    ymins = []
    ymaxs = []
    classes_text = []
    classes = []

    for index, row in example.object.iterrows():
        xmins.append(row['xmin'] / width)
        xmaxs.append(row['xmax'] / width)
        ymins.append(row['ymin'] / height)
        ymaxs.append(row['ymax'] / height)
        classes_text.append(row['class'].encode('utf8'))
        classes.append(class_text_to_int[row['class']])

    tf_example = tf.train.Example(features=tf.train.Features(feature={
        'image/height': dataset_util.int64_feature(height),
        'image/width': dataset_util.int64_feature(width),
        'image/filename': dataset_util.bytes_feature(filename),
        'image/encoded': dataset_util.bytes_feature(encoded_jpg),
        'image/format': dataset_util.bytes_feature(image_format),
        'image/object/bbox/xmin': dataset_util.float_list_feature(xmins),
        'image/object/bbox/xmax': dataset_util.float_list_feature(xmaxs),
        'image/object/bbox/ymin': dataset_util.float_list_feature(ymins),
        'image/object/bbox/ymax': dataset_util.float_list_feature(ymaxs),
        'image/object/class/text': dataset_util.bytes_list_feature(classes_text),
        'image/object/class/label': dataset_util.int64_list_feature(classes),
    }))
    return tf_example


def main(_):
    """Generate tfrecord files."""
    writer = tf.io.TFRecordWriter(FLAGS.output_path)
    examples = pd.read_csv(FLAGS.csv_input)
    grouped = split(examples, 'filename')
    for group in grouped:
        tf_example = create_tf_example(group, FLAGS.img_path)
        writer.write(tf_example.SerializeToString())
    writer.write(tf_example.SerializeToString())

    writer.close()
    print('Successfully created the TFRecords: {}'.format(FLAGS.output_path))


if __name__ == '__main__':
    app.run(main)
